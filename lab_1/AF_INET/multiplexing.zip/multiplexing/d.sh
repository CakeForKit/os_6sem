#!/bin/bash

rm data/m_cli_time_*.txt
rm data/thr_cli_time_*.txt