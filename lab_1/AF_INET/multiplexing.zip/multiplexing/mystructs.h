#ifndef MYSTRUCTS__
#define MYSTRUCTS__

#define serv_port 9877
#define len_buf 52

#endif // MYSTRUCTS__