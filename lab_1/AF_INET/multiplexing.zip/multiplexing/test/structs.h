
#define SERV_PORT 9878
#define BUF_SIZE 200
#define ARR_SIZE 78


typedef enum {OK, ALREADY_RESERVED, ERROR} msg_t;
